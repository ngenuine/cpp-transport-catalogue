#include "request_handler.h"
#include "json_reader.h"
// #include "test_framework.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {

// {
//     using namespace std;
//     using namespace renderer;

//     const double WIDTH = 600.0;
//     const double HEIGHT = 400.0;
//     const double PADDING = 50.0;
    
//     // Точки, подлежащие проецированию
//     vector<geo::Coordinates> geo_coords = {
//         {43.587795, 39.716901}, {43.581969, 39.719848}, {43.598701, 39.730623},
//         {43.585586, 39.733879}, {43.590317, 39.746833}
//     };

//     // Создаём проектор сферических координат на карту
//     const MapRenderer::SphereProjector proj{
//         geo_coords.begin(), geo_coords.end(), WIDTH, HEIGHT, PADDING
//     };

//     // Проецируем и выводим координаты
//     for (const auto geo_coord: geo_coords) {
//         const svg::Point screen_coord = proj(geo_coord);
//         cout << '(' << geo_coord.lat << ", "sv << geo_coord.lng << ") -> "sv;
//         cout << '(' << screen_coord.x << ", "sv << screen_coord.y << ')' << endl;
//     }
// }
    
    // tests::RunInputTests();
    // tests::RunTransportCatalogueTests();
    // tests::RunOutputTests();


    // считываем json из stdin
    JsonReader json_reader;
    json_reader.LoadJSON(cin);
    // или так
    // int n; cin >> n;
    // ifstream input("tst/ijson"s + to_string(n) + ".txt"s);
    // json_reader.LoadJSON(input);
    
    // создаем экземпляр фасада, который упростит взаимодействие классов при помощи агрегации
    RequestHandler request_handler(json_reader);

    // метод разберется, какие методы для каких запросов обработчика json надо применить
    request_handler.BuildTransportDatabase();
    request_handler.RenderMap(cout);
    // ofstream output("./tst/map.svg"s);
    // request_handler.RenderMap(output);



    // ответный json формируется при помощи информации из обработчика json
    // request_handler.SolveStatRequests(json_reader); // по условию первой задачи решение запросов к справочнику не пригодится

    // печатаем ответ в stdout    
    // request_handler.PrintSolution(cout); // по условию первой задачи не надо никакие ответы запросы к справочнику выводить
    // или так
    // ofstream output("tst/ojson"s + to_string(n) + ".txt"s);
    // request_handler.PrintSolution(output);
}