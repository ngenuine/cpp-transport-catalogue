#include "request_handler.h"

/*
 * Здесь можно было бы разместить код обработчика запросов к базе, содержащего логику, которую не
 * хотелось бы помещать ни в transport_catalogue, ни в json reader.
 *
 * Если вы затрудняетесь выбрать, что можно было бы поместить в этот файл,
 * можете оставить его пустым.
 */

RequestHandler::RequestHandler(const JsonReader& parsed_json)
    : parsed_json_(parsed_json)
    {
    }

void RequestHandler::BuildTransportDatabase() {
    // сначала надо добавить остановки, т.к. указатели на них в справочнике много где используются
    for (const Stop& stop : parsed_json_.GetStopRequests()) {
        db_.AddStop(stop);
    }

    // когда все возможные остановки находятся в каталоге, можно строить из них маршруты
    for (const RawBus& raw_bus : parsed_json_.GetBusRequests()) {
        db_.AddBus(raw_bus);
    }

    // также установим расстояния между остановками по дорогам
    for (const Neighbours& adjasent_stops : parsed_json_.GetDistancesRequests()) {
        db_.SetCurvedDistance(adjasent_stops);
    }
}

void RequestHandler::RenderMap(std::ostream& out) const {
    svg::Document buses; // карта маршрутов, которую надо будет отрендерить|вывести в out

    const RenderSettings& settings = parsed_json_.GetRenderSettings();

    // создадим проектор, который будет превращать градусы широты и долготы в координаты на экране
    // для этого ему потребуются:
    // 1) точки, участвующие в создании маршрутов
    const std::vector<geo::Coordinates>& stop_points = db_.GetUsefulStopCoordinates();
    // 2) ширина, высота, отступ
    const double width = std::get<double>(settings.at("width"s));
    const double height = std::get<double>(settings.at("height"s));
    const double padding = std::get<double>(settings.at("padding"s));

    renderer::SphereProjector projector{stop_points.begin(), stop_points.end(), width, height, padding};

    svg::Polyline base_bus_path;

    auto& color_palette = std::get<std::vector<std::string>>(settings.at("color_palette"s));
    
    auto get_color = [&color_palette](size_t color_order) {
        
        // вернет r -- остаток от деления a на b (r >= 0)
        auto mod = [](size_t a, size_t b) { return (a % b + b) % b; };

        std::string color = color_palette[mod(color_order, color_palette.size())];
        return color;
    };

    base_bus_path
        .SetStrokeWidth(std::get<double>(settings.at("line_width"s)))
        .SetStrokeLineCap(svg::StrokeLineCap::ROUND)
        .SetStrokeLineJoin(svg::StrokeLineJoin::ROUND)
        .SetFillColor(svg::NoneColor);

    size_t color_order = 0;
    for (const auto& [busname, ptr_bus] : db_.GetAllBuses()) {
        Bus& bus = *ptr_bus;
        if (bus.stops.size() == 0) {
            continue;
        }

        svg::Polyline bus_path{base_bus_path};

        bus_path.SetStrokeColor(get_color(color_order++));

        for (const Stop* stop : bus.stops) {
            bus_path.AddPoint(projector(stop->location));
        }

        if (!bus.is_cycle) {
            for (auto it = (++bus.stops.rbegin()); it != bus.stops.rend(); ++it) {
                bus_path.AddPoint(projector((*it)->location));
            }
        }

        buses.Add(std::move(bus_path));
    }

    buses.Render(out);
}

void RequestHandler::SolveStatRequests() {

    auto not_found = [](int id) {
        return json::Dict{
            {"request_id"s, id},
            {"error_message"s, "not found"s}};
    };

    json::Array answer;

    if (parsed_json_.GetStatRequests().size() == 0) {
        throw std::logic_error("Nothing to solve"s);
    }
    
    for (const Request& request : parsed_json_.GetStatRequests()) {
        
        if (request.type == "Bus"sv) {
            
            const BusInfo businfo = db_.GetBusInfo(request.name);

            if (businfo.number_of_stops > 0) {
                answer.push_back(
                    json::Dict{
                        {"curvature"s, businfo.curvature},
                        {"request_id"s, request.id},
                        {"route_length"s, businfo.bus_curved_length},
                        {"stop_count"s, businfo.number_of_stops},
                        {"unique_stop_count"s, businfo.number_of_unique_stops}
                    });
            } else {
                answer.push_back(not_found(request.id));
            }
        } else {

            const StopInfo stopinfo = db_.GetStopInfo(request.name);
            json::Array buses;

            if (stopinfo.is_exist) {
                for (BusName busname : *stopinfo.buses_across_stop) {
                    buses.push_back(std::string(busname));
                }

                // move(buses) и id превратятся в Node, потому что Dict = std::map<string, Node> и потому что у Node разрешена неявное преобразование типов
                answer.push_back(
                    json::Dict{
                        {"buses"s, move(buses)},
                        {"request_id"s, request.id}
                    });
            } else {
                answer.push_back(not_found(request.id));
            }
        }
    }

    solved_ = json::Document{answer};
}

void RequestHandler::PrintSolution(std::ostream& out) const {
    if (solved_) {
        json::Print(solved_.value(), out);
    } else {
        throw std::logic_error("Nothing to print"s);
    }
}