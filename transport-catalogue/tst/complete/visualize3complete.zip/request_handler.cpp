#include "request_handler.h"

/*
 * Здесь можно было бы разместить код обработчика запросов к базе, содержащего логику, которую не
 * хотелось бы помещать ни в transport_catalogue, ни в json reader.
 *
 * Если вы затрудняетесь выбрать, что можно было бы поместить в этот файл,
 * можете оставить его пустым.
 */

RequestHandler::RequestHandler(const JsonReader& parsed_json)
    : parsed_json_(parsed_json)
    {
    }

void RequestHandler::BuildTransportDatabase() {
    // сначала надо добавить остановки, т.к. указатели на них в справочнике много где используются
    for (const Stop& stop : parsed_json_.GetStopRequests()) {
        db_.AddStop(stop);
    }

    // когда все возможные остановки находятся в каталоге, можно строить из них маршруты
    for (const RawBus& raw_bus : parsed_json_.GetBusRequests()) {
        db_.AddBus(raw_bus);
    }

    // также установим расстояния между остановками по дорогам
    for (const Neighbours& adjasent_stops : parsed_json_.GetDistancesRequests()) {
        db_.SetCurvedDistance(adjasent_stops);
    }
}

void RequestHandler::RenderMap(std::ostream& out) const {

    const RenderSettings& settings = parsed_json_.GetRenderSettings();

    // создадим проектор, который будет превращать градусы широты и долготы в координаты на экране
    // для этого ему потребуются:
    // 1) точки, участвующие в создании маршрутов
    const std::map<StopName, geo::Coordinates>& stop_points = db_.GetUsefulStopCoordinates();
    // 2) ширина, высота, отступ
    const double width = std::get<double>(settings.at("width"s));
    const double height = std::get<double>(settings.at("height"s));
    const double padding = std::get<double>(settings.at("padding"s));

    renderer::SphereProjector projector{stop_points.begin(), stop_points.end(), width, height, padding};

    // получатель цвета (маршруты берут цвет из палитры по кругу)
    auto& color_palette = std::get<std::vector<std::string>>(settings.at("color_palette"s));
    
    size_t color_order = 0;
    auto get_next_color = [&color_palette, &color_order]() {
        
        // вернет r -- остаток от деления a на b (r >= 0)
        auto mod = [](size_t a, size_t b) { return (a % b + b) % b; };

        std::string color = color_palette[mod(color_order++, color_palette.size())];
        
        return color;
    };

    // настройка свойств линий маршрутов
    svg::Polyline base_bus_path;
    base_bus_path
        .SetStrokeWidth(std::get<double>(settings.at("line_width"s)))
        .SetStrokeLineCap(svg::StrokeLineCap::ROUND)
        .SetStrokeLineJoin(svg::StrokeLineJoin::ROUND)
        .SetFillColor(svg::NoneColor);

    // настройка свойств текста для подписи маршрутов
    auto [b_dx, b_dy] = std::get<std::pair<double, double>>(settings.at("bus_label_offset"s));
    svg::Text base_bus_text;
    base_bus_text
        .SetOffset({b_dx, b_dy})
        .SetFontSize(std::get<int>(settings.at("bus_label_font_size"s)))
        .SetFontFamily("Verdana"s)
        .SetFontWeight("bold"s);

    // настройка свойств подложки для подписи маршрутов
    std::string underlayer_color = std::get<std::string>(settings.at("underlayer_color"s));
    double underlayer_width = std::get<double>(settings.at("underlayer_width"s));
    
    svg::Text base_underlayer_bus_text{base_bus_text};
    base_underlayer_bus_text
        .SetFillColor(underlayer_color)
        .SetStrokeColor(underlayer_color)
        .SetStrokeWidth(underlayer_width)
        .SetStrokeLineCap(svg::StrokeLineCap::ROUND)
        .SetStrokeLineJoin(svg::StrokeLineJoin::ROUND);

    // "черновики" объектов документа: ломаных линий и названий маршрутов
    std::vector<svg::Text> buses_names;
    std::vector<svg::Polyline> buses;

    // надолняем "черновики" документа ломаными линиями маршрутов, названиями маршрутов, метками остановок и именами остановок
    for (const auto& [busname, ptr_bus] : db_.GetAllBuses()) {
        Bus& bus = *ptr_bus;
        if (bus.stops.size() == 0) {
            continue;
        }

        std::string bus_color = get_next_color();

        // донастраиваем подложку названия маршрута около первой остановки
        svg::Text underlayer_bus_text{base_underlayer_bus_text};
        underlayer_bus_text
            .SetData(std::string(bus.busname))
            .SetPosition(projector(bus.stops.front()->location));

        // донастраиваем текст названия маршрута около первой остановки
        svg::Text bus_text{base_bus_text};
        bus_text
            .SetData(std::string(bus.busname))
            .SetPosition(projector(bus.stops.front()->location))
            .SetFillColor(bus_color);

        // добавляем подложку и текст названия маршрута в "черновик"
        buses_names.push_back(underlayer_bus_text);
        buses_names.push_back(bus_text);

        // создаем ломаную линию маршрута
        svg::Polyline bus_path{base_bus_path};
        bus_path.SetStrokeColor(bus_color);
        for (const Stop* stop : bus.stops) {
            bus_path.AddPoint(projector(stop->location));
        }

        if (!bus.is_cycle) {
            for (auto it = (++bus.stops.rbegin()); it != bus.stops.rend(); ++it) {
                bus_path.AddPoint(projector((*it)->location));
            }
        }

        bool is_first_stop_is_same_last_stop =
            (bus.stops.front()->stopname == bus.stops.back()->stopname);
        // добавляем подложку и следом текст названия маршрута в "черновик" около последней остановки (если первая и последняя остановки не совпадают)
        if (!is_first_stop_is_same_last_stop) {
            underlayer_bus_text.SetPosition(projector(bus.stops.back()->location));
            bus_text.SetPosition(projector(bus.stops.back()->location));
            
            buses_names.push_back(underlayer_bus_text);
            buses_names.push_back(bus_text);

        }

        // добавляем ломаную линию маршрута в "черновик"
        buses.push_back(bus_path);
    }

    // настройка свойств окружностей остановок
    svg::Circle base_stop_symbol;
    base_stop_symbol
        .SetRadius(std::get<double>(settings.at("stop_radius"s)))
        .SetFillColor("white");
    
    // настройка свойств текста для подписи остановок
    auto [st_dx, st_dy] = std::get<std::pair<double, double>>(settings.at("stop_label_offset"s));
    svg::Text base_stop_text;
    base_stop_text
        .SetOffset({st_dx, st_dy})
        .SetFontSize(std::get<int>(settings.at("stop_label_font_size"s)))
        .SetFontFamily("Verdana"s);

    // настройка свойств подложки для подписи остановок
    svg::Text base_underlayer_stop_text{base_stop_text};
    base_underlayer_stop_text
        .SetFillColor(underlayer_color)
        .SetStrokeColor(underlayer_color)
        .SetStrokeWidth(underlayer_width)
        .SetStrokeLineCap(svg::StrokeLineCap::ROUND)
        .SetStrokeLineJoin(svg::StrokeLineJoin::ROUND);

    // "черновики" объектов документа: символов (окружности) и названий остановок
    std::vector<svg::Text> stop_names;
    std::vector<svg::Circle> stops;

    // наполняем "черновик" документа точками остановок и названиями остановок
    for (const auto& [stopname, stop_coordinates] : stop_points) {
        svg::Point coordinates = projector(stop_coordinates);

        svg::Circle stop_symbol{base_stop_symbol};
        stop_symbol.SetCenter(coordinates);
        stops.push_back(stop_symbol);
        
        svg::Text stop_text{base_stop_text};
        svg::Text underlayer_stop_text{base_underlayer_stop_text};

        // донастраиваем подложку названия остановки
        underlayer_stop_text
            .SetPosition(coordinates)
            .SetData(std::string(stopname));

        // донастраиваем текст названия остановки
        stop_text
            .SetFillColor("black")
            .SetPosition(coordinates)
            .SetData(std::string(stopname));
        
        // добавляем подложку и следом текст названия остановки в "черновик"
        stop_names.push_back(underlayer_stop_text);
        stop_names.push_back(stop_text);
    }

    // перемещаем "черновики" в svg::Document элементы в необходимом порядке
    svg::Document complete_map; // карта

    for (auto obj : buses) {
        complete_map.Add(obj);
    }
    for (auto obj : buses_names) {
        complete_map.Add(obj);
    }
    for (auto obj : stops) {
        complete_map.Add(obj);
    }
    for (auto obj : stop_names) {
        complete_map.Add(obj);
    }

    complete_map.Render(out);
}

void RequestHandler::SolveStatRequests() {

    auto not_found = [](int id) {
        return json::Dict{
            {"request_id"s, id},
            {"error_message"s, "not found"s}};
    };

    json::Array answer;

    if (parsed_json_.GetStatRequests().size() == 0) {
        throw std::logic_error("Nothing to solve"s);
    }
    
    for (const Request& request : parsed_json_.GetStatRequests()) {
        
        if (request.type == "Bus"sv) {
            
            const BusInfo businfo = db_.GetBusInfo(request.name);

            if (businfo.number_of_stops > 0) {
                answer.push_back(
                    json::Dict{
                        {"curvature"s, businfo.curvature},
                        {"request_id"s, request.id},
                        {"route_length"s, businfo.bus_curved_length},
                        {"stop_count"s, businfo.number_of_stops},
                        {"unique_stop_count"s, businfo.number_of_unique_stops}
                    });
            } else {
                answer.push_back(not_found(request.id));
            }
        } else if (request.type == "Stop"sv) {

            const StopInfo stopinfo = db_.GetStopInfo(request.name);
            json::Array buses;

            if (stopinfo.is_exist) {
                for (BusName busname : *stopinfo.buses_across_stop) {
                    buses.push_back(std::string(busname));
                }

                // move(buses) и id превратятся в Node, потому что Dict = std::map<string, Node> и потому что у Node разрешена неявное преобразование типов
                answer.push_back(
                    json::Dict{
                        {"buses"s, move(buses)},
                        {"request_id"s, request.id}
                    });
            } else {
                answer.push_back(not_found(request.id));
            }
        } else if (request.type == "Map"sv) {
            std::stringstream svg_map;
            RenderMap(svg_map);
            answer.push_back(
                    json::Dict{
                        {"map"s, svg_map.str()},
                        {"request_id"s, request.id},
                    });
        } else {

            throw std::logic_error("Unknown request: " + "\""s + request.type + "\""s);
        }
    }

    solved_ = json::Document{answer};
}

void RequestHandler::PrintSolution(std::ostream& out) const {
    if (solved_) {
        json::Print(solved_.value(), out);
    } else {
        throw std::logic_error("Nothing to print"s);
    }
}