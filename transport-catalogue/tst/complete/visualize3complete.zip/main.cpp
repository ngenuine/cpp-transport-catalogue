#include "request_handler.h"
#include "json_reader.h"
// #include "test_framework.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    
    // tests::RunInputTests();
    // tests::RunTransportCatalogueTests();
    // tests::RunOutputTests();

    JsonReader json_reader;
    // считываем json из stdin
    json_reader.LoadJSON(cin);
    // или так
    // int n; cin >> n;
    // ifstream input("./tst/ijson"s + to_string(n) + ".txt"s);
    // json_reader.LoadJSON(input);
    
    // создаем экземпляр фасада, который упростит взаимодействие классов при помощи агрегации
    RequestHandler request_handler(json_reader);

    // метод разберется, какие методы для каких запросов обработчика json надо применить
    request_handler.BuildTransportDatabase();

    // формируется ответный json
    request_handler.SolveStatRequests();

    // печатаем ответ в stdout    
    request_handler.PrintSolution(cout);
    // или так
    // ofstream output("./tst/ojson"s + to_string(n) + ".txt"s);
    // request_handler.PrintSolution(output);
}